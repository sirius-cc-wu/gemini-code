"""
Gemini CLI - A command-line interface for interacting with various LLM models.
"""

__version__ = "0.1.65"